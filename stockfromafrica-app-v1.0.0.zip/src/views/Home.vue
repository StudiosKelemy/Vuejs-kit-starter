<template>
    <div class="home">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus dignissimos asperiores fugiat ab autem deleniti cum, iure quia dolore molestias animi magnam modi corrupti optio ipsa a obcaecati delectus aut.
    </div>
</template>

<script>
export default {
    name: 'Home',
    components: {
        HelloWorld
    }
}
</script>
